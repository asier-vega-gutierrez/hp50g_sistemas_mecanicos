LibEx 4.2 by Pivo

This library extractor may be used in your own program
if duely credited and you do not sell it.

It extracts libraries installed in any port into a directory.
Put the LibId on the stack and run LE42.BIN

Stack:

(real/zint) -> DIR

If the number on the stack is negative it does not rename rompointers
to variable names. (Useful for compressed libs)


Known libraries that fail (Syntax problems):

Jazz
Extable
TNT

The source is in LE42.TXT, unfortunately it is not commented (anymore)